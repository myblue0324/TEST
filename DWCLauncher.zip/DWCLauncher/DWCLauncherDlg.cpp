
// DWCLauncherDlg.cpp : implementation file
//

#include "stdafx.h"
#include "DWCLauncher.h"
#include "DWCLauncherDlg.h"
#include "BindStatusCallback.h"
#include "unzip.h"

#include <AclAPI.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CDWCLauncherDlg dialog




CDWCLauncherDlg::CDWCLauncherDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CDWCLauncherDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

	bIs64Bit = true;
}

void CDWCLauncherDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_STATIC_TITLE, m_ctrlStaticTitle);
	DDX_Control(pDX, IDC_STATIC_SUB, m_ctrlStaticSub);
	DDX_Control(pDX, IDC_PROGRESS_MAIN, m_ctrlProgressMain);
}

BEGIN_MESSAGE_MAP(CDWCLauncherDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_WM_TIMER()
END_MESSAGE_MAP()


// CDWCLauncherDlg message handlers

BOOL CDWCLauncherDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// ���� �ʱ�ȭ
	oldVersion = -1;
	newVersion = -1;
	bNeedDownload = false;
	m_ctrlProgressMain.SetRange(0, 100);
	m_ctrlProgressMain.SetPos(0);

	// �ʱ� Ÿ��Ʋ ���� �� �������� �̸� ����
	m_ctrlStaticTitle.SetWindowText(_T("������ ���α׷��� ��ġ�ƴ��� Ȯ���մϴ�."));
	exeName = CString(_T(EXE_NAME));

	// window ������ ���� exe ��ġ Ǯ��� ����
	if(osVersion == OS_NONE)
	{
		AfxMessageBox(_T("�������� �ʴ� OS�̹Ƿ� �����մϴ�."));
		this->SetTimer(EXIT_TIMER, 1000, NULL);
		return TRUE;
	}
	else
	{
#ifdef _TEST_
		SetWindowText(_T("DWCLauncher(����)"));
		if(bIs64Bit)
		{
			exeLocation = CString(_T("C:/Program Files (x86)/KMA/DWCT/DigitalWeatherChart"));
			baseLocation = CString(_T("C:/Program Files (x86)"));
			downloadLocation = CString(_T("C:/Program Files (x86)/KMA/DWCT"));
		}
		else
		{
			exeLocation = CString(_T("C:/Program Files/KMA/DWCT/DigitalWeatherChart"));
			baseLocation = CString(_T("C:/Program Files"));
			downloadLocation = CString(_T("C:/Program Files/KMA/DWCT"));
		}
#elif _EVAL_
		if(bIs64Bit)
		{
			exeLocation = CString(_T("C:/Program Files (x86)/KMA/DWC/EvalDigitalWeatherChart"));
			baseLocation = CString(_T("C:/Program Files (x86)"));
			downloadLocation = CString(_T("C:/Program Files (x86)/KMA/DWC"));
		}
		else
		{
			exeLocation = CString(_T("C:/Program Files/KMA/DWC/EvalDigitalWeatherChart"));
			baseLocation = CString(_T("C:/Program Files"));
			downloadLocation = CString(_T("C:/Program Files/KMA/DWC"));
		}
#else
		if(bIs64Bit)
		{
			exeLocation = CString(_T("C:/Program Files (x86)/KMA/DWC/DigitalWeatherChart"));
			baseLocation = CString(_T("C:/Program Files (x86)"));
			downloadLocation = CString(_T("C:/Program Files (x86)/KMA/DWC"));
		}
		else
		{
			exeLocation = CString(_T("C:/Program Files/KMA/DWC/DigitalWeatherChart"));
			baseLocation = CString(_T("C:/Program Files"));
			downloadLocation = CString(_T("C:/Program Files/KMA/DWC"));
		}
#endif
	}

	// timer�� update ����. Ÿ�̸ӷ� ���� ������ ���̾˷αװ� ������ ����.
	this->SetTimer(UPDATE_TIMER, 1000, NULL);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CDWCLauncherDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CDWCLauncherDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CDWCLauncherDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


void CDWCLauncherDlg::OnTimer(UINT_PTR nIDEvent)
{
	this->KillTimer(nIDEvent);

	switch(nIDEvent)
	{
	case EXIT_TIMER:
		{
			this->SendMessage(WM_CLOSE);
		}
		break;
	case EXECUTE_TIMER:
		{
			executeExe();

			this->SendMessage(WM_CLOSE);
		}
		break;
	case UPDATE_TIMER:
		{
			// ������ ��ġ�� ���α׷� �˻�
			findExeOnLocal();

			// download
			if(downloadVersionInfo() && downloadExeToBeInstalled() && installDownloadedExe())
			{
				m_ctrlStaticTitle.SetWindowText(_T("�ٿ�ε尡 �Ϸ�Ǿ����ϴ�. ���α׷��� �����մϴ�."));
				this->SetTimer(EXECUTE_TIMER, 1000, NULL);
			}
			else
				this->SendMessage(WM_CLOSE);		
		}
		break;
	}

	CDialog::OnTimer(nIDEvent);
}


bool CDWCLauncherDlg::findExeOnLocal()
{
	CFileFind finder;
	CString exeFullPath;
	exeFullPath.Format(_T("%s/%s"), exeLocation, exeName);
	if(finder.FindFile(exeFullPath) == TRUE)
	{
		finder.Close();
		return findInstalledExeVersion();
	}
	else
	{
		bNeedDownload = true;
		return false;
	}
}

bool CDWCLauncherDlg::findInstalledExeVersion()
{
	m_ctrlStaticTitle.SetWindowText(_T("������ ��ġ�� ���α׷��� ������ Ȯ���մϴ�."));

	char versionFile[BUFSIZE*4];
	memset(versionFile, 0x00, BUFSIZE*4);

	CString wVersionFile;
	wVersionFile.Format(_T("%s/%s"), exeLocation, _T(VERSION_FILE_NAME));

	int nSize = WideCharToMultiByte(CP_ACP, 0, wVersionFile, -1, NULL, 0, NULL, NULL);
	WideCharToMultiByte(CP_ACP, 0, wVersionFile, -1, versionFile, nSize, NULL, NULL);


	FILE* file = NULL;
	file = fopen(versionFile, "rt");

	if(file == NULL)
	{
		bNeedDownload = true;
		return false;
	}

	char versionContent[VERSION_INFO_SIZE + 1];
	memset(versionContent, 0x00, VERSION_INFO_SIZE + 1);

	size_t nContents = fread(versionContent, 1, VERSION_INFO_SIZE, file);
	fclose(file);
	if(nContents < VERSION_INFO_SIZE)
	{
		bNeedDownload = true;
		return false;
	}

	oldVersion = atoi(versionContent);
	if(oldVersion == 0)
	{
		bNeedDownload = true;
		return false;
	}

	return true;
}

bool CDWCLauncherDlg::downloadVersionInfo()
{
	m_ctrlStaticTitle.SetWindowText(_T("�ٿ�ε� ������ Ȯ���մϴ�. �ִ� 1���� �ҿ�˴ϴ�."));

	CString strURL, strPath;
	strURL.Format(_T("%s/%s"), sourceLocation, _T(VERSION_FILE_NAME));
	strPath.Format(_T("%s/%s"), exeLocation, _T(VERSION_TEMP_FILE_NAME));

	// �ϴ� ������ �����ϴ��� Ȯ��. ������ ����� ���� ��.
	CFileFind finder;
	
	if(finder.FindFile(exeLocation) == FALSE)
	{
		char fullDir[BUFSIZE];
		memset(fullDir, 0x00, BUFSIZE);
		int nSize = WideCharToMultiByte(CP_ACP, 0, exeLocation, -1, NULL, 0, NULL, NULL);
		WideCharToMultiByte(CP_ACP, 0, exeLocation, -1, fullDir, nSize, NULL, NULL);

		createFullDirectory(fullDir);

		if(finder.FindFile(exeLocation) == FALSE)
		{
			AfxMessageBox(_T("C����̺꿡 ���� ������ �����ϴ�.\n ���ĸ� �����մϴ�."));
			return false;
		}
	}

	CCallback callback;
	callback.m_pDlg = this;
	callback.m_bUseTimeout = TRUE;
	callback.m_timeToStop = CTime::GetCurrentTime() + CTimeSpan( 0, 0, 0, 60);

	// 2014. 10. 15
	// DeleteUrlCacheEntry �Լ��� ĳ�ð� �������� �ʴ� ����
	//DeleteUrlCacheEntry(strURL);
	srand(time(NULL));
	CString randKey;
	randKey.Format(_T("?Key=%d"),rand());
	strURL=strURL+randKey;

	HRESULT hr = URLDownloadToFile(NULL, strURL, strPath, 0, &callback);
	if ( SUCCEEDED(hr) )
	{
		char versionFile[BUFSIZE*4];
		memset(versionFile, 0x00, BUFSIZE*4);

		CString wVersionFile;
		wVersionFile.Format(_T("%s/%s"), exeLocation, _T(VERSION_TEMP_FILE_NAME));

		int nSize = WideCharToMultiByte(CP_ACP, 0, wVersionFile, -1, NULL, 0, NULL, NULL);
		WideCharToMultiByte(CP_ACP, 0, wVersionFile, -1, versionFile, nSize, NULL, NULL);

		FILE* file = NULL;
		file = fopen(versionFile, "rt");

		if(file == NULL)
		{
			AfxMessageBox(_T("�ٿ�ε� ���� �������� ������ ���� �� �����ϴ�.\n���ĸ� �����մϴ�."));
			return false;
		}

		char versionContent[VERSION_INFO_SIZE + 1];
		memset(versionContent, 0x00, VERSION_INFO_SIZE + 1);

		size_t nContents = fread(versionContent, 1, VERSION_INFO_SIZE + 1, file);
		fclose(file);
		if(nContents < VERSION_INFO_SIZE)
		{
			AfxMessageBox(_T("�������� ���� ���뿡 ������ �ֽ��ϴ�.\n���ĸ� �����մϴ�."));
			return false;
		}

		newVersion = atoi(versionContent);
		if(newVersion == 0)
		{
			AfxMessageBox(_T("�������� ���� ���뿡 ������ �ֽ��ϴ�.\n���ĸ� �����մϴ�."));
			return false;
		}

		if(!bNeedDownload && (oldVersion < newVersion))
			bNeedDownload = true;

		DeleteUrlCacheEntry(strURL);
	}
	else
	{
		LPTSTR lpszErrorMessage;
		CString sMsg;

		if ( FormatMessage ( FORMAT_MESSAGE_ALLOCATE_BUFFER | 
			FORMAT_MESSAGE_FROM_SYSTEM | 
			FORMAT_MESSAGE_IGNORE_INSERTS,
			NULL, hr, 
			MAKELANGID ( LANG_NEUTRAL, SUBLANG_DEFAULT ),
			(LPTSTR) &lpszErrorMessage, 0, NULL ))
		{
			sMsg.Format ( _T("versionInformation.txt Download failed.\nError = 0x%08lX\n\n%s"),
				(DWORD) hr, lpszErrorMessage );

			LocalFree ( lpszErrorMessage );
		}
		else
		{
			sMsg.Format ( _T("versionInformation.txt Download failed.\nError = 0x%08lX\n\nNo message available."),
				(DWORD) hr );
		}

		AfxMessageBox(sMsg);
		return false;
	}

	return true;
}

bool CDWCLauncherDlg::downloadExeToBeInstalled()
{
	m_ctrlStaticTitle.SetWindowText(_T("���α׷��� �ٿ�ε� �մϴ�.\n�ִ� 5�б��� �ɸ� �� ������ �׵��� ���α׷��� �������� ���ʽÿ�."));
	m_ctrlProgressMain.SetPos(0);

	if(!bNeedDownload)
	{
		m_ctrlProgressMain.SetPos(100);
		return true;
	}

	CString strURL, strPath;
	strURL.Format(_T("%s/%s"), sourceLocation, _T(INSTALL_FILE_NAME));
	strPath.Format(_T("%s/%s"), downloadLocation, _T(INSTALL_FILE_NAME));

	CCallback callback;
	callback.m_pDlg = this;
	callback.m_bUseTimeout = TRUE;
	callback.m_timeToStop = CTime::GetCurrentTime() + CTimeSpan( 0, 0, 0, 300);

	// 2014. 10. 15
	// DeleteUrlCacheEntry �Լ��� ĳ�ð� �������� �ʴ� ����
	//DeleteUrlCacheEntry(strURL);
	srand(time(NULL));
	CString randKey;
	randKey.Format(_T("?Key=%d"),rand());
	strURL=strURL+randKey;

	HRESULT hr = URLDownloadToFile(NULL, strURL, strPath, 0, &callback);
	if ( SUCCEEDED(hr) )
	{
		DeleteUrlCacheEntry(strURL);
		return true;
	}
	else
	{
		LPTSTR lpszErrorMessage;
		CString sMsg;

		if ( FormatMessage ( FORMAT_MESSAGE_ALLOCATE_BUFFER | 
			FORMAT_MESSAGE_FROM_SYSTEM | 
			FORMAT_MESSAGE_IGNORE_INSERTS,
			NULL, hr, 
			MAKELANGID ( LANG_NEUTRAL, SUBLANG_DEFAULT ),
			(LPTSTR) &lpszErrorMessage, 0, NULL ))
		{
			sMsg.Format ( _T("zip Download failed.\nError = 0x%08lX\n\n%s"),
				(DWORD) hr, lpszErrorMessage );

			LocalFree ( lpszErrorMessage );
		}
		else
		{
			sMsg.Format ( _T("zip Download failed.\nError = 0x%08lX\n\nNo message available."),
				(DWORD) hr );
		}

		AfxMessageBox(sMsg);
		return false;
	}

	return true;
}

bool CDWCLauncherDlg::installDownloadedExe()
{
	m_ctrlProgressMain.SetPos(0);
	m_ctrlStaticTitle.SetWindowText(_T("���α׷��� ��ġ �մϴ�."));

	if(!bNeedDownload)
	{
		m_ctrlProgressMain.SetPos(100);
		return true;
	}

	clearDirectory(exeLocation);

	CString pathToBeDeleted;
	pathToBeDeleted.Format(_T("%s/*.*"), exeLocation);
	DeleteFile(pathToBeDeleted);

	CString zipPath;
	zipPath.Format(_T("%s/%s"), downloadLocation, _T(INSTALL_FILE_NAME));
	HZIP hz = OpenZip(zipPath, 0);
	if(hz == NULL)
	{
		AfxMessageBox(_T("��ġ���� ���������� �����߽��ϴ�."));
		return false;
	}
	SetUnzipBaseDir(hz, exeLocation);

	ZIPENTRY zipInfo;
	GetZipItem(hz, -1, &zipInfo);

	int nZipItem = zipInfo.index;
	CString strUnzipStatus;
	strUnzipStatus.Format(_T("�� %d�� �� 0�� ��������"), nZipItem);
	m_ctrlStaticSub.SetWindowText(strUnzipStatus);
	for(int i = 0; i < nZipItem; i++)
	{
		ZIPENTRY ze;
		GetZipItem(hz, i, &ze);
		UnzipItem(hz, i, ze.name);

		m_ctrlProgressMain.SetPos((int)(100.0 * (i+1) / nZipItem));
		strUnzipStatus.Format(_T("�� %d�� �� %d�� ��������"), nZipItem, i+1);
		m_ctrlStaticSub.SetWindowText(strUnzipStatus);
	}

	CloseZip(hz);

	DeleteFile(zipPath);
	CString tempVersionFile;
	tempVersionFile.Format(_T("%s/%s"), exeLocation, _T(VERSION_TEMP_FILE_NAME));
	DeleteFile(tempVersionFile);

	char versionFile[BUFSIZE*4];
	memset(versionFile, 0x00, BUFSIZE*4);
	CString wVersionFile;
	wVersionFile.Format(_T("%s/%s"), exeLocation, _T(VERSION_FILE_NAME));
	int nSize = WideCharToMultiByte(CP_ACP, 0, wVersionFile, -1, NULL, 0, NULL, NULL);
	WideCharToMultiByte(CP_ACP, 0, wVersionFile, -1, versionFile, nSize, NULL, NULL);

	FILE* file = NULL;
	file = fopen(versionFile, "wt");
	fprintf(file, "%.8d", newVersion);
	fclose(file);

	return true;
}

void CDWCLauncherDlg::executeExe()
{
	CString exeFullPath;
	exeFullPath.Format(_T("%s/%s"), exeLocation, exeName);
	CString parameters;
	parameters.Format(_T("%s %s"), CString(loginID), CString(sessionID));
	::ShellExecute(NULL, _T("open"), exeFullPath, parameters, NULL,  SW_SHOWMAXIMIZED);
}

void CDWCLauncherDlg::ProgressUpdate ( LPCTSTR szIEMsg,
									  LPCTSTR szCustomMsg,
									  const int nPercentDone )
{
	ASSERT ( AfxIsValidString ( szIEMsg ));
	ASSERT ( AfxIsValidString ( szCustomMsg ));
	ASSERT ( nPercentDone >= 0  &&  nPercentDone <= 100 );

	m_ctrlStaticTitle.SetWindowText(szCustomMsg);

	m_ctrlProgressMain.SetPos ( nPercentDone );
}

void CDWCLauncherDlg::createFullDirectory(char* path)
{
	if(strlen(path) <= 0) return;

	char eachDir[BUFSIZE];
	memset(eachDir, 0x00, BUFSIZE);

	char* sourceMarker = path;
	char* targetMarker = eachDir;

	DWORD lastError;
	while(*sourceMarker != 0)
	{
		if( *sourceMarker == '\\' || *sourceMarker == '/')
		{
			if(*(sourceMarker-1) != ':')
			{
				CreateDirectory(CString(eachDir), NULL);
				lastError =::GetLastError();
			}
		}

		*targetMarker++ = *sourceMarker++;
	}

	CreateDirectory(CString(eachDir), NULL);
}

void CDWCLauncherDlg::clearDirectory(CString path)
{
	CFileFind finder;
	CString filter;
	filter.Format(_T("%s/*.*"), path);
	BOOL bExist = finder.FindFile(filter);
	while(bExist == TRUE)
	{
		bExist = finder.FindNextFile();

		CString target;
		target = finder.GetFilePath();
		if (finder.IsDirectory() == TRUE)
		{
			if(target.Right(1) != CString(_T('.')))
			{
				clearDirectory(target);
				RemoveDirectory(target);
			}
		}
		else
		{
			DeleteFile(target);
		}
	}

	finder.Close();
}