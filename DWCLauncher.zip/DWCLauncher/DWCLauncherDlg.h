
// DWCLauncherDlg.h : header file
//

#pragma once
#include "afxwin.h"
#include "afxcmn.h"

#include "resource.h"

#define EXIT_TIMER 1101
#define UPDATE_TIMER 1102
#define EXECUTE_TIMER 1103
#ifdef _EVAL_
#define VERSION_FILE_NAME "evalVersionInformation.txt"
#define VERSION_TEMP_FILE_NAME "evalVersionInformationTemp.txt"
#define INSTALL_FILE_NAME "EvalDWC_setup.zip"
#define EXE_NAME "EvalDigitalWeatherChart.exe"
#else
#define VERSION_FILE_NAME "versionInformation.txt"
#define VERSION_TEMP_FILE_NAME "versionInformationTemp.txt"
#define INSTALL_FILE_NAME "DWCDemo_setup.zip"
#define EXE_NAME "DigitalWeatherChart.exe"
#endif
// CDWCLauncherDlg dialog
class CDWCLauncherDlg : public CDialog
{
// Construction
public:
	CDWCLauncherDlg(CWnd* pParent = NULL);	// standard constructor

	bool findExeOnLocal();
	bool findInstalledExeVersion();
	bool downloadVersionInfo();
	bool downloadExeToBeInstalled();
	bool installDownloadedExe();
	void executeExe();
	void ProgressUpdate ( LPCTSTR szIEMsg, LPCTSTR szCustomMsg,	const int nPercentDone );

// Dialog Data
	enum { IDD = IDD_DWCLAUNCHER_DIALOG };
	enum OS_VERSION {OS_NONE = -1, XP, VISTA, WINDOW7};

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	void createFullDirectory(char* path);
	void clearDirectory(CString path);

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	CStatic m_ctrlStaticTitle;
	CStatic m_ctrlStaticSub;
	CProgressCtrl m_ctrlProgressMain;

	OS_VERSION osVersion;
	bool bIs64Bit;
	CString loginID;
	CString sessionID;
	CString sourceLocation;
	CString exeLocation;
	CString exeName;
	CString baseLocation;
	CString downloadLocation;

	int oldVersion;
	int newVersion;

	bool bNeedDownload;

	afx_msg void OnTimer(UINT_PTR nIDEvent);
};
