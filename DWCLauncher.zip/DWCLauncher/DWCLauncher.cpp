
// DWCLauncher.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "DWCLauncher.h"
#include "DWCLauncherDlg.h"

#include <windows.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CDWCLauncherApp

BEGIN_MESSAGE_MAP(CDWCLauncherApp, CWinAppEx)
	ON_COMMAND(ID_HELP, &CWinApp::OnHelp)
END_MESSAGE_MAP()


// CDWCLauncherApp construction

CDWCLauncherApp::CDWCLauncherApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}


// The one and only CDWCLauncherApp object

CDWCLauncherApp theApp;


// CDWCLauncherApp initialization

BOOL CDWCLauncherApp::InitInstance()
{
	// InitCommonControlsEx() is required on Windows XP if an application
	// manifest specifies use of ComCtl32.dll version 6 or later to enable
	// visual styles.  Otherwise, any window creation will fail.
	INITCOMMONCONTROLSEX InitCtrls;
	InitCtrls.dwSize = sizeof(InitCtrls);
	// Set this to include all the common control classes you want to use
	// in your application.
	InitCtrls.dwICC = ICC_WIN95_CLASSES;
	InitCommonControlsEx(&InitCtrls);

	CWinAppEx::InitInstance();

	AfxEnableControlContainer();

	// Standard initialization
	// If you are not using these features and wish to reduce the size
	// of your final executable, you should remove from the following
	// the specific initialization routines you do not need
	// Change the registry key under which our settings are stored
	// TODO: You should modify this string to be something appropriate
	// such as the name of your company or organization
	SetRegistryKey(_T("Local AppWizard-Generated Applications"));

	CDWCLauncherDlg dlg;

	// command arguement �޾ƿ���
	CString cmdLine(this->m_lpCmdLine);
	CString sessionID = cmdLine.Mid(cmdLine.ReverseFind(_T(' ')) + 1, cmdLine.GetLength() - cmdLine.ReverseFind(_T(' ')) - 1);
	CString tmpCmdLine1 = cmdLine.Left(cmdLine.ReverseFind(_T(' ')));
	CString sourceLocation = tmpCmdLine1.Mid(tmpCmdLine1.ReverseFind(_T(' ')) + 1, tmpCmdLine1.GetLength() - tmpCmdLine1.ReverseFind(_T(' ')) - 1);
	CString tmpCmdLine2 = tmpCmdLine1.Left(tmpCmdLine1.ReverseFind(_T(' ')));
	CString loginID = tmpCmdLine2.Mid(tmpCmdLine2.ReverseFind(_T(' ')) + 1, tmpCmdLine2.GetLength() - tmpCmdLine2.ReverseFind(_T(' ')) - 1);

	dlg.loginID = loginID;
	dlg.sessionID = sessionID;
	dlg.sourceLocation = sourceLocation;
	//////////////////////////////////////////////////////

	// OS version �˱�
	int nIs64Bit = 0;
	typedef int (WINAPI *LPFN_ISWOW64PROCESS) (HANDLE, PBOOL);
	LPFN_ISWOW64PROCESS fnIsWow64Process;
	fnIsWow64Process = (LPFN_ISWOW64PROCESS) GetProcAddress(
		GetModuleHandle(TEXT("kernel32")),"IsWow64Process");

	if(NULL != fnIsWow64Process)
	{
		if (!fnIsWow64Process(GetCurrentProcess(),&nIs64Bit))
		{
			return FALSE;
		}
	}
	else
		return FALSE;

	dlg.bIs64Bit = (nIs64Bit == 0) ? false : true;

	OSVERSIONINFO osv;
	memset(&osv, 0x00, sizeof(OSVERSIONINFO));
	osv.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
	GetVersionEx(&osv);
	dlg.osVersion = CDWCLauncherDlg::OS_NONE;
	if(osv.dwMajorVersion == 5 && osv.dwMinorVersion ==1) // xp
		dlg.osVersion = CDWCLauncherDlg::XP;
	else if(osv.dwMajorVersion == 6 && osv.dwMinorVersion == 0) // vista
		dlg.osVersion = CDWCLauncherDlg::VISTA;
	else if(osv.dwMajorVersion == 6 && osv.dwMinorVersion == 1) // window 7
		dlg.osVersion = CDWCLauncherDlg::WINDOW7;
	//////////////////////////////////////////////////////

	m_pMainWnd = &dlg;
	INT_PTR nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with OK
	}
	else if (nResponse == IDCANCEL)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with Cancel
	}

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}
